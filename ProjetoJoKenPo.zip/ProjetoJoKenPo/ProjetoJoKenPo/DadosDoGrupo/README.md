João Ramalho Sampaio RA: 12522169379
Arthur Lohan Rosa Lira RA: 12522173628
Alana Ventura Maróstica RA: 12522162470
Silvio Augusto Pochini RA:  12522182781